def get_max(c, b, a):
    if c >= b and c >= a:
        return c
    elif b >= c and b >= a:
        return b
    elif a >= b and a >= c: 
        return a