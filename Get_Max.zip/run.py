from func import get_max

c = int(input())
b = int(input())
a = int(input())

print(get_max(c, b, a))
